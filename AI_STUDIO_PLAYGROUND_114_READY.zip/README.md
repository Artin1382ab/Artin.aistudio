# AI Studio Managed Agent 114 skills

Mount the `.agents` folder as `/workspace/.agents`, or use the included Python `create_managed_agent.py` (114 inline sources). Not an importable one-click Skills ZIP for Build Mode.
